'use strict';

/**
 * @ngdoc function
 * @name clarityAppApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the clarityAppApp
 */
angular.module('clarityAppApp')
  .controller('MainCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
